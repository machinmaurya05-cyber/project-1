<?php
$conn=mysqli_connect("localhost","root","","support_system");
if(!$conn){die("DB Failed");}
?>